package dev.voidclient;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public final class VoidClient implements ClientModInitializer {
    private static KeyBinding openMenu;
    private static boolean hudEnabled = true;
    private static boolean particlesEnabled = true;

    @Override
    public void onInitializeClient() {
        openMenu = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.voidclient.open_menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                KeyBinding.Category.MISC
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenu.wasPressed()) {
                if (client.currentScreen == null) client.setScreen(new VoidScreen());
                else if (client.currentScreen instanceof VoidScreen) client.setScreen(null);
            }
        });

        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (!hudEnabled || client.player == null || client.options.hudHidden) return;
            int x = 8, y = 8;
            drawContext.fill(x - 4, y - 4, x + 112, y + 43, 0xA9101018);
            drawContext.fill(x - 4, y - 4, x + 112, y - 2, 0xFFB64DFF);
            drawContext.drawTextWithShadow(client.textRenderer, Text.literal("✦ VoidClient"), x, y, 0xFFD58BFF);
            drawContext.drawTextWithShadow(client.textRenderer, Text.literal("FPS: " + MinecraftClient.getCurrentFps()), x, y + 12, 0xFFE8E1F2);
            drawContext.drawTextWithShadow(client.textRenderer, Text.literal("XYZ: " +
                    (int) client.player.getX() + " " + (int) client.player.getY() + " " +
                    (int) client.player.getZ()), x, y + 24, 0xFFC8B4DD);
        });
    }

    static boolean isParticlesEnabled() { return particlesEnabled; }
    static void setParticlesEnabled(boolean enabled) { particlesEnabled = enabled; }
    static boolean isHudEnabled() { return hudEnabled; }
    static void setHudEnabled(boolean enabled) { hudEnabled = enabled; }

    private static final class VoidScreen extends Screen {
        private int panelX, panelY, panelW, panelH;

        protected VoidScreen() {
            super(Text.literal("VoidClient"));
        }

        @Override
        protected void init() {
            panelW = 300;
            panelH = 220;
            panelX = (width - panelW) / 2;
            panelY = (height - panelH) / 2;
            int bx = panelX + 18;
            int bw = panelW - 36;
            int bh = 22;
            int gap = 8;
            addDrawableChild(net.minecraft.client.gui.widget.ButtonWidget.builder(
                    Text.literal("HUD: " + (hudEnabled ? "ON" : "OFF")), button -> {
                        hudEnabled = !hudEnabled;
                        button.setMessage(Text.literal("HUD: " + (hudEnabled ? "ON" : "OFF")));
                    }).dimensions(bx, panelY + 55, bw, bh).build());
            addDrawableChild(net.minecraft.client.gui.widget.ButtonWidget.builder(
                    Text.literal("Ambient particles: " + (particlesEnabled ? "ON" : "OFF")), button -> {
                        particlesEnabled = !particlesEnabled;
                        button.setMessage(Text.literal("Ambient particles: " + (particlesEnabled ? "ON" : "OFF")));
                    }).dimensions(bx, panelY + 55 + bh + gap, bw, bh).build());
            addDrawableChild(net.minecraft.client.gui.widget.ButtonWidget.builder(
                    Text.literal("Save settings"), button -> VoidConfig.save(hudEnabled, particlesEnabled))
                    .dimensions(bx, panelY + 55 + (bh + gap) * 2, bw, bh).build());
            addDrawableChild(net.minecraft.client.gui.widget.ButtonWidget.builder(
                    Text.literal("Close"), button -> close())
                    .dimensions(bx, panelY + 55 + (bh + gap) * 3, bw, bh).build());
        }

        @Override
        public void render(DrawContext context, int mouseX, int mouseY, float delta) {
            renderBackground(context, mouseX, mouseY, delta);
            context.fill(panelX, panelY, panelX + panelW, panelY + panelH, 0xF20B0B12);
            context.fill(panelX, panelY, panelX + panelW, panelY + 3, 0xFFB64DFF);
            context.drawCenteredTextWithShadow(textRenderer, Text.literal("VOIDCLIENT"), width / 2, panelY + 14, 0xFFD58BFF);
            context.drawCenteredTextWithShadow(textRenderer, Text.literal("NEON PURPLE  •  CLIENT SETTINGS"), width / 2, panelY + 32, 0xFFBEB0D0);
            super.render(context, mouseX, mouseY, delta);
            context.drawCenteredTextWithShadow(textRenderer, Text.literal("Right Shift  •  Cosmetic & performance tools"), width / 2, panelY + panelH - 15, 0xFF9E8CAB);
        }

        @Override
        public boolean shouldPause() { return false; }
    }
}
