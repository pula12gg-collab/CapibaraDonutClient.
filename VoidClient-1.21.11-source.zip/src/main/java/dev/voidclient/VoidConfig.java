package dev.voidclient;

import net.minecraft.client.MinecraftClient;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

final class VoidConfig {
    private VoidConfig() {}

    static void save(boolean hud, boolean particles) {
        MinecraftClient client = MinecraftClient.getInstance();
        Path path = client.runDirectory.toPath().resolve("config").resolve("voidclient.json");
        try {
            Files.createDirectories(path.getParent());
            Files.writeString(path, "{\n  \"hud\": " + hud + ",\n  \"particles\": " + particles + "\n}\n");
            if (client.player != null) client.player.sendMessage(net.minecraft.text.Text.literal("§dVoidClient: settings saved."), true);
        } catch (IOException exception) {
            if (client.player != null) client.player.sendMessage(net.minecraft.text.Text.literal("§cVoidClient: couldn't save settings."), true);
        }
    }
}
