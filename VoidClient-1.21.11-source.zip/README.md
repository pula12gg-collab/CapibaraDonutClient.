# VoidClient 0.1.0 — Minecraft Java 1.21.11

A first prototype of a client-side Fabric mod with a black / neon-purple settings screen.

## Included in this prototype
- Right Shift opens the VoidClient settings menu.
- Small HUD with FPS and XYZ coordinates.
- HUD toggle.
- Ambient-particles setting toggle (the toggle is stored as a setting placeholder; custom particles are not implemented yet).
- Save settings writes `config/voidclient.json`.
- No combat cheats, automation, reach changes, or server-side advantages.

## Not implemented yet
- Actual 3D Custom Shy model / cape renderer.
- Applying custom skins or capes (those normally require a skin/cape resource or service).
- Real graphics/performance optimizations. The HUD displays FPS but does not change Minecraft's rendering engine.
- Loading saved values back on startup; this prototype currently writes the settings file only.

## Build requirements
- Java 21
- Gradle 8.14+ (the Fabric Loom plugin may require a compatible newer Gradle version)
- Internet for Gradle to download Minecraft, mappings and Fabric dependencies.

From this folder, run:
- Linux / Chromebook Linux: `gradle build`
- Windows: `gradle.bat build` if Gradle is installed, or import the folder into IntelliJ IDEA and use its Gradle panel.

The compiled mod should appear at `build/libs/VoidClient-0.1.0.jar` (not the `-sources` jar).

## Install on Chromebook with MjLauncher
1. Build the project on a computer/container with Java 21 and Gradle, or ask someone to build the source project for you.
2. In MjLauncher, open the game directory / instance folder for Minecraft 1.21.11 Fabric.
3. Put `VoidClient-0.1.0.jar` in that instance's `mods` folder.
4. Ensure Fabric API for Minecraft 1.21.11 is also in `mods`.
5. Launch the 1.21.11 Fabric profile and press Right Shift in-game.

If the game crashes, remove the VoidClient JAR from `mods` and check `latest.log`.

## Notes
This archive is the source project, not a precompiled `.jar`. MjLauncher is an Android/ChromeOS launcher, and its file locations vary by setup.
