package net.capibara.client;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class ClientMenuScreen extends Screen {
    public ClientMenuScreen() {
        super(Component.literal("Capibara Donut Client"));
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
        int centerX = this.width / 2;
        int centerY = this.height / 2;

        graphics.fill(centerX - 120, centerY - 90, centerX + 120, centerY + 90, 0xEE11151B);
        graphics.fill(centerX - 120, centerY - 90, centerX + 120, centerY - 66, 0xFF202A36);
        graphics.drawCenteredString(this.font, "CAPIBARA DONUT CLIENT", centerX, centerY - 82, 0xFF55CCFF);

        drawToggle(graphics, centerX, centerY - 35, "HUD (FPS + coordinates)", CapibaraClient.hudEnabled, mouseX, mouseY);
        drawToggle(graphics, centerX, centerY + 5, "Auto Sprint", CapibaraClient.sprintEnabled, mouseX, mouseY);

        graphics.drawCenteredString(this.font, "Click a row to toggle", centerX, centerY + 54, 0xFFB7C4D1);
        graphics.drawCenteredString(this.font, "Right Shift or ESC to close", centerX, centerY + 70, 0xFF7F91A3);
        super.render(graphics, mouseX, mouseY, delta);
    }

    private void drawToggle(GuiGraphics graphics, int centerX, int centerY, String label,
                            boolean enabled, int mouseX, int mouseY) {
        int left = centerX - 100;
        int right = centerX + 100;
        int top = centerY - 8;
        int bottom = centerY + 22;
        boolean hovered = mouseX >= left && mouseX <= right && mouseY >= top && mouseY <= bottom;
        graphics.fill(left, top, right, bottom, hovered ? 0xFF2A3948 : 0xFF1B232D);
        graphics.drawString(this.font, label, left + 10, top + 10, 0xFFFFFFFF);
        String status = enabled ? "ON" : "OFF";
        graphics.drawString(this.font, status, right - 30, top + 10, enabled ? 0xFF55FF99 : 0xFFFF7777);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button == 0) {
            int centerX = this.width / 2;
            int centerY = this.height / 2;
            if (mouseX >= centerX - 100 && mouseX <= centerX + 100) {
                if (mouseY >= centerY - 43 && mouseY <= centerY - 13) {
                    CapibaraClient.hudEnabled = !CapibaraClient.hudEnabled;
                    return true;
                }
                if (mouseY >= centerY - 3 && mouseY <= centerY + 27) {
                    CapibaraClient.sprintEnabled = !CapibaraClient.sprintEnabled;
                    return true;
                }
            }
        }
        return super.mouseClicked(mouseX, mouseY, button);
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 256 || keyCode == 344) {
            this.minecraft.setScreen(null);
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
