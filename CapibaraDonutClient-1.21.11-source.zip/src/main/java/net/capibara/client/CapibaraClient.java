package net.capibara.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.Identifier;
import org.lwjgl.glfw.GLFW;

public class CapibaraClient implements ClientModInitializer {
    public static boolean hudEnabled = true;
    public static boolean sprintEnabled = false;

    private static KeyMapping openMenuKey;

    @Override
    public void onInitializeClient() {
        KeyMapping.Category category = KeyMapping.Category.register(
                Identifier.fromNamespaceAndPath("capibara_donut_client", "main")
        );

        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.capibara_donut_client.open_menu",
                InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                category
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.consumeClick()) {
                if (client.screen == null) {
                    client.setScreen(new ClientMenuScreen());
                } else if (client.screen instanceof ClientMenuScreen) {
                    client.setScreen(null);
                }
            }

            if (sprintEnabled && client.player != null && client.player.input != null) {
                if (client.player.input.hasForwardImpulse()) {
                    client.player.setSprinting(true);
                }
            }
        });

        HudElementRegistry.addLast(
                Identifier.fromNamespaceAndPath("capibara_donut_client", "main_hud"),
                (graphics, deltaTracker) -> {
                    Minecraft client = Minecraft.getInstance();
                    if (!hudEnabled || client.player == null || client.options.hideGui) {
                        return;
                    }

                    var player = client.player;
                    String line = String.format(
                            "Capibara | FPS: %d | XYZ: %.1f %.1f %.1f",
                            client.getFps(), player.getX(), player.getY(), player.getZ()
                    );
                    graphics.drawString(client.font, line, 6, 6, 0xFF55CCFF, true);
                }
        );
    }
}
