# Capibara Donut Client (Minecraft 1.21.11)

A starter client-side Fabric mod project. It includes:
- Right Shift menu
- FPS and coordinates HUD
- HUD toggle
- Auto Sprint toggle

## Build on Chromebook without Developer Mode

This project includes a GitHub Actions workflow so you do not need Linux/Developer Mode on the Chromebook.

1. Create a new repository on GitHub (keep it private if you prefer).
2. Upload the contents of this ZIP to the repository. Make sure `.github/workflows/build.yml` is included.
3. Open the repository's **Actions** tab.
4. Select **Build Fabric mod** and press **Run workflow** (or push/commit files to `main` to trigger it).
5. When the run finishes, open the run and download the `capibara-donut-client` artifact.
6. Extract the downloaded artifact ZIP. The `.jar` inside is the mod file.
7. In MjLauncher, open the Minecraft 1.21.11 Fabric instance's mods folder and place the JAR there. Make a backup first.

## Important
- This is a starter project, not a precompiled or tested JAR.
- It requires Minecraft Java 1.21.11, Fabric Loader, and a matching Fabric API.
- Only use on servers where the relevant features are allowed. Auto Sprint is optional and can be disabled in the menu.
- The build workflow downloads dependencies from Gradle/Fabric repositories, so the first build may take a few minutes.
